
// import daw.com.Teclado;

// public class LeerDigitosComoString {

// 	public static void main(String[] args) {
// 		// TODO Auto-generated method stub
		
// 		String m;
		
// 		m = Teclado.leerString();
		
// 		// leer sólo dígitos
// 		System.out.println(m.matches("[0-9]*"));
// 		boolean salida = true;
// 		while(salida == true) {
// 			if(dataCliente) {
// 				salida = false;
// 			}
			
// 		}
		
		
// 	}
	

// }
